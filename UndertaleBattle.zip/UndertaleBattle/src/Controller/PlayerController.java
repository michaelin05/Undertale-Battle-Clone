package Controller;

import Model.BattleContainer;
import Model.Player;
import View.BattlePanel;

import java.awt.*;

public class PlayerController
{
    private Player playerM;
    private BattlePanel bp;
    private BattleContainer bc;

    public PlayerController(BattlePanel bp, BattleContainer bc)
    {
        this.playerM = new Player(bp.getKh(),bp.getScreenWidth()/2, bp.getScreenHeight()/2,16,16, bc);
        this.bp = bp;
        setDefaultValues();
    }

    public void setDefaultValues()
    {
        this.playerM.setDefaultValues(bp.getTileSize(), bp.getScreenWidth()/2, bp.getScreenHeight()/2);
    }

    public void update()
    {
        this.playerM.update();
    }

    public void drawPlayer(Graphics2D g2, int tileSize)
    {
        this.playerM.drawPlayer(g2, tileSize);
    }

    public Player getPlayer()
    {
        return this.playerM;
    }
}
