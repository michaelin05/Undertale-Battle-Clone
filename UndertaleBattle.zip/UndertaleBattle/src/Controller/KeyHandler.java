package Controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener
{
    private Boolean upPressed, leftPressed, downPressed, rightPressed,onePressed, twoPressed, threePressed, attackPressed;

    public KeyHandler()
    {
        upPressed = false;
        leftPressed = false;
        downPressed = false;
        rightPressed = false;
        threePressed = false;
        attackPressed = false;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e)
    {
        int code = e.getKeyCode();
        if(code == KeyEvent.VK_W || code == KeyEvent.VK_UP)
        {
            upPressed = true;
        }
        if(code == KeyEvent.VK_A || code == KeyEvent.VK_LEFT)
        {
            leftPressed = true;
        }
        if(code == KeyEvent.VK_S || code == KeyEvent.VK_DOWN)
        {
            downPressed = true;
        }
        if(code == KeyEvent.VK_D || code == KeyEvent.VK_RIGHT)
        {
            rightPressed = true;
        }
        if(code == KeyEvent.VK_1)
        {
            onePressed = true;
            twoPressed = false;
            threePressed = false;
        }
        if(code == KeyEvent.VK_2)
        {
            twoPressed = true;
            onePressed = false;
            threePressed = false;
        }
        if(code == KeyEvent.VK_3)
        {
            threePressed = true;
            onePressed = false;
            twoPressed = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_SPACE) { // Assuming space is the attack key
            attackPressed = true;
        }

    }

    @Override
    public void keyReleased(KeyEvent e)
    {
        int code = e.getKeyCode();
        if(code == KeyEvent.VK_W || code == KeyEvent.VK_UP)
        {
            upPressed = false;
        }
        if(code == KeyEvent.VK_A || code == KeyEvent.VK_LEFT)
        {
            leftPressed = false;
        }
        if(code == KeyEvent.VK_S || code == KeyEvent.VK_DOWN)
        {
            downPressed = false;
        }
        if(code == KeyEvent.VK_D || code == KeyEvent.VK_RIGHT)
        {
            rightPressed = false;
        }
        if(code == KeyEvent.VK_3)
        {
            threePressed = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            attackPressed = false;
        }

    }

    public Boolean getUpPressed() {return upPressed;}
    public void setUpPressed(Boolean upPressed) {
        this.upPressed = upPressed;
    }
    public Boolean getLeftPressed() {
        return leftPressed;
    }
    public void setLeftPressed(Boolean leftPressed) {
        this.leftPressed = leftPressed;
    }
    public Boolean getDownPressed() {
        return downPressed;
    }
    public void setDownPressed(Boolean downPressed) {
        this.downPressed = downPressed;
    }
    public Boolean getRightPressed() {
        return rightPressed;
    }
    public void setRightPressed(Boolean rightPressed) {
        this.rightPressed = rightPressed;
    }
    public Boolean getThreePressed() {return threePressed;}
    public void setThreePressed(Boolean threePressed) {this.threePressed = threePressed;}

    public Boolean getOnePressed() {return onePressed;}
    public void setOnePressed(Boolean onePressed) {this.onePressed = onePressed;}
    public Boolean getTwoPressed() {return twoPressed;}
    public void setTwoPressed(Boolean twoPressed) {this.twoPressed = twoPressed;}

    public boolean isAttackPressed() {
        return attackPressed;
    }
}
