package Controller;

import Model.Attack;
import Model.Enemy;
import Model.Player;
import View.BattlePanel;

import java.awt.*;

public class EnemyController
{
    Enemy enemy;
    BattlePanel bp;

    public EnemyController(BattlePanel bp)
    {
        this.enemy = new Enemy(bp.getScreenWidth()/2,bp.getScreenHeight()/2, 2);
        this.bp = bp;
    }

    public void update(Player p)
    {
        this.enemy.update(p);
    }

    public void drawEnemy(Graphics2D g2)
    {
        this.enemy.draw(g2);
    }


}
