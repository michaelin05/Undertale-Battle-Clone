package Controller;

import Model.BattleContainer;
import View.BattlePanel;

import java.awt.*;

public class BattleContainerController
{
    BattleContainer bc = new BattleContainer();
    BattleContainer pc = new BattleContainer();
    BattlePanel bp;
    KeyHandler kh;

    public BattleContainerController(BattlePanel bp, KeyHandler kh)
    {
        this.kh = kh;
        this.bp = bp;

        bc.setScreenX((bp.getScreenWidth()/2) -220); //548px
        bc.setScreenY(bp.getScreenHeight()/2 + 128); //106px

        pc.setScreenX(bp.getMaxScreenX()/4); //(3,0)
        pc.setScreenY(bp.getMaxScreenY()/4); //(0,2)

    }

    public void drawBox(Graphics2D g2)
    {
        this.bc.drawBox(g2);
    }

    public BattleContainer getBc() {return bc;}
    public void setBc(BattleContainer bc) {this.bc = bc;}
    public BattlePanel getBp() {return bp;}
    public void setBp(BattlePanel bp) {this.bp = bp;}
    public KeyHandler getKh() {return kh;}
    public void setKh(KeyHandler kh) {this.kh = kh;}
}
