package Controller;

import Model.Player;
import Model.UI;
import View.BattlePanel;

import java.awt.*;

public class UIController
{
    private UI ui;
    private Player p;
    private BattlePanel bp;

    public UIController(BattlePanel bp, Player p)
    {
        this.ui = new UI(p, bp.getScreenWidth()/3, bp.getScreenHeight());
        this.bp = bp;
        this.p = p;
    }

    public void draw(Graphics2D g2)
    {
        this.ui.draw(g2,this.bp);
    }
}
