import Controller.KeyHandler;
import Controller.PlayerController;
import Model.Player;
import View.BattlePanel;
import View.MainWindow;

public class App
{
    public static void main(String[] args)
    {
        KeyHandler kh = new KeyHandler();
        BattlePanel bp = new BattlePanel(kh);
        MainWindow mw = new MainWindow(bp);

    }
}