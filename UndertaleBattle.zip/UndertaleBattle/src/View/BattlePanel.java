package View;

import Controller.*;
import Model.UI;

import javax.swing.*;
import java.awt.*;

public class BattlePanel extends JPanel implements Runnable
{
    private final int originalTileSize = 32;
    private final int scale = 2;
    private final int tileSize = originalTileSize * scale;
    private final int maxScreenX = 12;
    private final int maxScreenY = 9;
    private final int screenWidth = tileSize * maxScreenX; // 768 pixels
    private final int screenHeight = tileSize * maxScreenY; // 576 pixels

    private PlayerController PlayerC;
    private EnemyController ec;
    private BattleContainerController mc;
    private KeyHandler kh;

    private UIController ui;
    private Thread gameThread;

    private int FPS = 60;

    public BattlePanel(KeyHandler kh)
    {
        this.kh = kh;


        this.mc = new BattleContainerController(this, kh);

        this.mc.getBc().setScreenX((screenWidth/3));
        this.mc.getBc().setScreenY(screenHeight/3);
        this.mc.getBc().setWidth(275);
        this.mc.getBc().setHeight(200);

        this.PlayerC = new PlayerController(this, this.mc.getBc());
        this.ec = new EnemyController(this);

        this.ui = new UIController(this, this.PlayerC.getPlayer());

        this.mc.setBp(this);
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true); //draws things offscreen
        this.addKeyListener(kh);
        this.setFocusable(true);
    }

    public void startGameThread()
    {
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public void run()
    {
        double drawInterval = 1000000000/FPS; //0.01666
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        long timer = 0;
        int drawCount = 0;




        while(gameThread != null)
        {
            currentTime = System.nanoTime();

            delta += (currentTime - lastTime) / drawInterval;
            timer += (currentTime - lastTime);
            lastTime = currentTime;

            if(delta >= 1)
            {
                update();
                repaint();
                delta--;
                drawCount++;
            }

            if(timer >= 1000000000)
            {
                //System.out.println("FPS:" + drawCount);
                drawCount = 0;
                timer = 0;
            }

        }

    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        // middle of the screen
        /*
        g2.setColor(Color.RED);
        g2.fillRect(this.getScreenWidth() / 2, this.getScreenHeight() / 2, 16, 16);

         */

        // Drawing the player and boxes

        this.mc.drawBox(g2);
        this.PlayerC.drawPlayer(g2, this.tileSize);
        this.ec.drawEnemy(g2);

        this.ui.draw(g2);
        g2.dispose();
    }


    public void update() {
        this.PlayerC.update();
        this.ec.update(this.PlayerC.getPlayer()); // Update enemy logic
    }


    public int getOriginalTileSize() {return originalTileSize;}
    public int getScale() {return scale;}
    public int getTileSize() {return tileSize;}
    public int getMaxScreenX() {return maxScreenX;}
    public int getMaxScreenY() {return maxScreenY;}
    public int getScreenWidth() {return screenWidth;}
    public int getScreenHeight() {return screenHeight;}
    public Thread getGameThread() {return gameThread;}
    public void setGameThread(Thread gameThread) {this.gameThread = gameThread;}
    public int getFPS() {return FPS;}
    public void setFPS(int FPS) {this.FPS = FPS;}

    public KeyHandler getKh() {return kh;}

    public void setKh(KeyHandler kh) {this.kh = kh;}
}
