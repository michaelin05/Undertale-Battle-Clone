package View;

import javax.swing.*;

public class MainWindow extends JFrame
{
    public MainWindow(BattlePanel bp)
    {
        JFrame window = new JFrame();
        window.setName("Battle Pane");
        window.add(bp);
        window.pack();

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);



        window.setLocationRelativeTo(null);
        window.setVisible(true);

        bp.startGameThread();
    }
}
