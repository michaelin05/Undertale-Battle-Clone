package Model;

import java.util.ArrayList;

public class BattleHud
{
    private int switchNum;
    private int[] options;
    public BattleHud(int switchNum)
    {
        this.options = new int[2];
        this.switchNum = switchNum;
    }




}
