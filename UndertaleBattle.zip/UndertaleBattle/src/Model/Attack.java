package Model;

import java.awt.*;

public class Attack {
    private int x, y;
    private int speed;
    private Rectangle collisionBox;
    private int atkType; //if 0 it's a vertical attack, if 1 it's a horizontal attack;
    private boolean hit;

    public Attack(int x, int y, int speed, int atkType)
    {
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.collisionBox = new Rectangle(this.x, this.y);
        this.hit = false;
        this.atkType = atkType;
    }

    public void update(Player p, Enemy e)
    {
        if(this.atkType == 0)
        {
            y += speed; // Move bullet downwards
        }
        else if(this.atkType == 1)
        {
            x += speed;
        }

        collisionBox.x = this.x;
        collisionBox.y = this.y;
        collisionBox.height = 5;
        collisionBox.width = 5;

        hitChecker(p,e);

    }

    public void draw(Graphics2D g2) {
        g2.setColor(Color.YELLOW);
        g2.fillRect(x, y, 8, 10); // Draw bullet
    }

    public boolean isOffScreen() {
        return y < 0 || y > 576 || x > 768; // Check if the bullet is off-screen
    }

    public Rectangle getCollisionBox()
    {
        return this.collisionBox;
    }

    public int getX() { return x; }
    public int getY() { return y; }

    public void hitChecker(Player p, Enemy e)
    {
        if(p.getBoxCollider().intersects(this.collisionBox))
        {
            e.damage(p);
            this.hit = true;
        }
    }

    public boolean getHit()
    {
        return this.hit;
    }
}

