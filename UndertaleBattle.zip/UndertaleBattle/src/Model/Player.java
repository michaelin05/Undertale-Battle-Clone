package Model;

import Controller.KeyHandler;

import java.awt.*;
import java.util.ArrayList;

public class Player extends Entity {
    private KeyHandler kh;
    private Rectangle boxCollider;
    private BattleContainer bc;
    private static final String UP = "up";
    private static final String DOWN = "down";
    private static final String LEFT = "left";
    private static final String RIGHT = "right";
    private static final String UP_LEFT = "up-left";
    private static final String UP_RIGHT = "up-right";
    private static final String DOWN_LEFT = "down-left";
    private static final String DOWN_RIGHT = "down-right";

    private int health;

    private ArrayList<Item> items;
    private boolean fighting;

    public Player(KeyHandler kh, int x, int y, int width, int height, BattleContainer bc)
    {
        this.kh = kh;
        this.bc = bc;
        this.health = 20;
        this.boxCollider = new Rectangle(x, y, width, height);
        this.items = new ArrayList<Item>();
        this.fighting = true;
    }

    public void setDefaultValues(int tileSize, int x, int y) {
        this.health = 20;
        this.setX(x);
        this.setY(y);
        this.setSpeed(4);
        this.setDirection(DOWN); // Default direction
    }

    public Rectangle getBoxCollider() {
        return this.boxCollider;
    }

    public void controls() {
        String direction = "";

        if (kh.getUpPressed()) direction = UP;
        if (kh.getLeftPressed()) direction = LEFT;
        if (kh.getDownPressed()) direction = DOWN;
        if (kh.getRightPressed()) direction = RIGHT;
        if (kh.getUpPressed()&&kh.getLeftPressed()) direction = UP_LEFT;
        if (kh.getUpPressed()&&kh.getRightPressed()) direction = UP_RIGHT;
        if (kh.getDownPressed()&&kh.getLeftPressed()) direction = DOWN_LEFT;
        if (kh.getDownPressed()&&kh.getRightPressed()) direction = DOWN_RIGHT;

        // move while colliding on walls
        if (kh.getLeftPressed() && kh.getUpPressed() && willCollideDirection(LEFT))
            direction = UP;
        if (kh.getLeftPressed() && kh.getDownPressed() && willCollideDirection(LEFT))
            direction = DOWN;
        if (kh.getRightPressed() && kh.getUpPressed() && willCollideDirection(RIGHT))
            direction = UP;
        if (kh.getRightPressed() && kh.getDownPressed() && willCollideDirection(RIGHT))
            direction = DOWN;

        if(kh.getUpPressed() && kh.getRightPressed() && willCollideDirection(UP))
            direction = RIGHT;
        if(kh.getUpPressed() && kh.getLeftPressed() && willCollideDirection(UP))
            direction = LEFT;
        if(kh.getDownPressed() && kh.getLeftPressed() && willCollideDirection(DOWN))
            direction = LEFT;
        if(kh.getDownPressed() && kh.getRightPressed() && willCollideDirection(DOWN))
            direction = RIGHT;
        // Handle movement
        if (!direction.isEmpty()) {
            move(direction);
        }
    }
    public boolean willCollideDirection(String dir)
    {
        switch (dir) {
            case UP -> {
                if (y - speed < this.bc.getScreenY()) return true;
            }
            case DOWN -> {
                if ((y + this.boxCollider.height) + speed > this.bc.getScreenY() + this.bc.getHeight()) return true;
            }
            case LEFT -> {
                if (x - speed < this.bc.getScreenX()) return true;
            }
            case RIGHT -> {
                if ((x + this.boxCollider.width) + speed > this.bc.getScreenX() + this.bc.getWidth()) return true;
            }

            case UP_LEFT -> {
                if (y - speed < this.bc.getScreenY() || x - speed < this.bc.getScreenX()) return true;
            }
            case UP_RIGHT -> {
                if (y - speed < this.bc.getScreenY() || (x + this.boxCollider.width) + speed > this.bc.getScreenX() + this.bc.getWidth())
                    return true;
            }
            case DOWN_LEFT -> {
                if ((y + this.boxCollider.height) + speed > this.bc.getScreenY() + this.bc.getHeight() || x - speed < this.bc.getScreenX())
                    return true;
            }
            case DOWN_RIGHT -> {
                if ((y + this.boxCollider.height) + speed > this.bc.getScreenY() + this.bc.getHeight() || (x + this.boxCollider.width) + speed > this.bc.getScreenX() + this.bc.getWidth())
                    return true;
            }
            default -> {
                return false;
            }
        }
       // Return false if no collision detected
        return false;
    }

    public ArrayList<Item> getItems()
    {
        return this.items;
    }

    public void useHealingItem(int i)
    {
        if(this.health >20 || this.health + i >20)
            return;
        else if(this.health + i <=20)
            setHealth(health + i);

        this.items.remove(i);
    }

    public int getHealth()
    {
        return this.health;
    }

    public void setHealth(int i)
    {
        this.health = i;
    }

    public void takeDamage(int i)
    {
        if(health > 0)
        {
            setHealth(this.health -= i);
        }
        if(health == 0)
        {
            this.gameOver();
        }

        System.out.println(this.health + "/20");
    }

    private void gameOver()
    {
        this.fighting = false;
    }

    private void move(String direction)
    {
        if(fighting)
            if (willCollideDirection(direction))
                return;
            else
                switch (direction) {
                    case UP: y -= speed;break;
                    case DOWN: y += speed;break;
                    case LEFT: x -= speed;break;
                    case RIGHT: x += speed;break;
                    case UP_LEFT: y-= speed; x -= speed; break;
                    case UP_RIGHT: y -= speed; x += speed; break;
                    case DOWN_LEFT: y += speed; x -= speed; break;
                    case DOWN_RIGHT: y+= speed; x += speed; break;
        }

        // Update box collider position
        boxCollider.setLocation(x, y);
    }
    public void update() {controls();}
    public void drawPlayer(Graphics2D g2, int tileSize) {
        g2.setColor(Color.WHITE);
        g2.fillRect((int)x, (int)y, tileSize / 4, tileSize / 4);
    }

    public boolean isFighting() {return fighting;}
    public void setFighting(boolean fighting) {this.fighting = fighting;}
}
