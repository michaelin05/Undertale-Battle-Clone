package Model;

public class HealingItem extends Item
{
    private int value;

    public HealingItem(String name, int value, String desc)
    {
        this.name = name;
        this.value = value;
        this.desc = desc;
        this.keyItem = false;
    }

    public HealingItem()
    {
        name = "Absolutely nothing";
        value = 0;
        desc = "A whole lot of nothing, not even moths";
        keyItem = false;
    }

}
