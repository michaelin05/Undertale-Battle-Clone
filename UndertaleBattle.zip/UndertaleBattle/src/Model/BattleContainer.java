package Model;

import Controller.KeyHandler;

import java.awt.*;

public class BattleContainer {
    private int screenX, screenY, width, height;

    public BattleContainer(int screenX, int screenY, int width, int height) {
        this.screenX = screenX;
        this.screenY = screenY;
        this.width = width;
        this.height = height;
    }

    //Screen
    public BattleContainer() {
        this(0, 0, 448, 96);
    }

    public void drawBox(Graphics2D g2)
    {
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(4));
        g2.drawRect(screenX, screenY, width, height);
    }
    public int getScreenX() { return screenX; }
    public void setScreenX(int screenX) { this.screenX = screenX; }
    public int getScreenY() { return screenY; }
    public void setScreenY(int screenY) { this.screenY = screenY; }
    public int getWidth() { return width; }
    public void setWidth(int width) { this.width = width; }
    public int getHeight() { return height; }
    public void setHeight(int height) { this.height = height; }


}