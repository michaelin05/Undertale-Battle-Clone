package Model;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class Enemy {
    private int x, y;
    private int atkPower;
    private Random random;
    private int shootTimer;
    private ArrayList<Attack> enemyBullets;


    public Enemy(int x, int y, int atkPower)
    {
        this.x = x;
        this.y = y;
        this.atkPower = atkPower;
        this.enemyBullets = new ArrayList<>();
        this.shootTimer = 0;
        this.random = new Random();
    }

    public void damage(Player p)
    {
        p.takeDamage(atkPower);
    }

    public void update(Player p)
    {
        horizontalAttack(p);
        verticalAttack(p);


    }

    public void horizontalAttack(Player p)
    {
        shootTimer++;
        if(shootTimer > random.nextInt(30) + 30)
        {
            int randomX = random.nextInt(1,2);
            int randomY = random.nextInt(106,424);
            enemyBullets.add(new Attack(randomX,randomY,5,1));
            shootTimer = 0;
        }

        for (int i = 0; i < enemyBullets.size(); i++) {
            enemyBullets.get(i).update(p, this);

            if (enemyBullets.get(i).getHit()) {
                enemyBullets.remove(i);
                i--;
                System.out.println("hit");
            } else {
                if (enemyBullets.get(i).isOffScreen()) {
                    enemyBullets.remove(i);
                    i--;
                }
            }
        }

    }


    public void verticalAttack(Player p)
    {
        shootTimer++;
        if (shootTimer > random.nextInt(30) + 30)
        { // Shoot every 30-90 frames
            int randomX = random.nextInt(220,500); // Random x position within range
            int randomY = random.nextInt(0,2); // Random y position within range
            enemyBullets.add(new Attack(randomX, randomY, 5,0)); // Spawn bullet at random position
            shootTimer = 0; // Reset timer
        }

        // Update enemy bullets
        for (int i = 0; i < enemyBullets.size(); i++) {
            enemyBullets.get(i).update(p, this);

            if (enemyBullets.get(i).getHit()) {
                enemyBullets.remove(i);
                i--;
                System.out.println("hit");
            } else {
                if (enemyBullets.get(i).isOffScreen()) {
                    enemyBullets.remove(i);
                    i--;
                }
            }
        }
    }


    public void draw(Graphics2D g2) {
        g2.setColor(Color.RED);
        g2.fillRect(x, 10, 32, 32); // Draw enemy

        for (Attack bullet : enemyBullets) {
            bullet.draw(g2); // Draw all enemy bullets
        }
    }

    public ArrayList<Attack> getEnemyBullets()
    {
        return this.enemyBullets;
    }
}
