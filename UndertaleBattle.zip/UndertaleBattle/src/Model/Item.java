package Model;

public class Item
{
    public String name;
    public boolean keyItem;
    public String desc;

}
