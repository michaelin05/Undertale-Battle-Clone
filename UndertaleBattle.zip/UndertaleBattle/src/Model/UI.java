package Model;

import View.BattlePanel;

import java.awt.*;
import java.text.DecimalFormat;

public class UI
{
    private Player p;
    private int maxHP;

    private int x,y;
    private Font arial; // arial font with size 40

    private double timer;
    private DecimalFormat df = new DecimalFormat("#0.00");

    public UI(Player p, int x, int y)
    {
        this.p = p;
        this.x = x;
        this.y = y;

        this.maxHP = 20;
        this.arial = new Font("Arial", Font.PLAIN, 40);
    }

    public void draw(Graphics2D g2, BattlePanel bp)
    {

        if(!this.p.isFighting())
        {
            String go = "GAME OVER";
            int textLength = (int)g2.getFontMetrics().getStringBounds(go,g2).getWidth();
            int goX = bp.getScreenWidth()/3 + textLength * 2;
            int goY = bp.getScreenHeight()/2;
            g2.setFont(arial);

            g2.drawString(go,this.x, this.y);
            g2.drawString("Time:" + df.format(this.timer), 0,30);
        }
        else
        {
            g2.setFont(arial);
            g2.setColor(Color.white);
            this.timer += (double)1/60;
            g2.drawString("Time:" + df.format(this.timer), 0,30);
            g2.drawString("Health: "+ this.p.getHealth() + "/" + this.maxHP,this.x,this.y);
        }


    }
}
